package com.example.helloworld1;

public class uploadUserDataJavaClass {
    public String userFirstName, userLastName, userDOB, userProfilePicURL;

    public String getUserFirstName() {
        return userFirstName;
    }

    public void setUserFirstName(String userFirstName) {
        this.userFirstName = userFirstName;
    }

    public String getUserLastName() {
        return userLastName;
    }

    public void setUserLastName(String userLastName) {
        this.userLastName = userLastName;
    }

    public String getUserDOB() {
        return userDOB;
    }

    public void setUserDOB(String userDOB) {
        this.userDOB = userDOB;
    }

    public String getUserProfilePicURL() {
        return userProfilePicURL;
    }

    public void setUserProfilePicURL(String userProfilePicURL) {
        this.userProfilePicURL = userProfilePicURL;
    }

    public uploadUserDataJavaClass(String userFirstName, String userLastName, String userDOB, String userProfilePicURL) {
        this.userFirstName = userFirstName;
        this.userLastName = userLastName;
        this.userDOB = userDOB;
        this.userProfilePicURL = userProfilePicURL;
    }

    public uploadUserDataJavaClass() {
    }
}
