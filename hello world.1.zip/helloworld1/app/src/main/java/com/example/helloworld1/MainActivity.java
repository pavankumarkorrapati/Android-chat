package com.example.helloworld1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    private EditText loginActivity_emailID,loginActivity_password;
    private Button loginActivity_loginBtn;
    private TextView loginActivity_newUser;
    private FirebaseAuth loginActivity_firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        CastComponents();
        loginActivity_newUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,registerUserActivity.class));
            }
        });
        loginActivity_loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailID = loginActivity_emailID.getText().toString().trim();
                String password = loginActivity_password.getText().toString();
                if (emailID.equals("") && password.equals("")) {
                    Toast.makeText(MainActivity.this,"Email or password cannot be empty",Toast.LENGTH_SHORT).show();
                }else {
                  loginUserMethod(emailID, password);
                }
            }
        });

    }
  private void loginUserMethod(String userID , String password){
        loginActivity_firebaseAuth.signInWithEmailAndPassword(userID, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
             Toast.makeText(MainActivity.this,"Logged In Successfully",Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
              Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });

  }


    private void CastComponents(){
        loginActivity_emailID = (EditText) findViewById(R.id.loginActivity_emailID);
        loginActivity_password = (EditText) findViewById(R.id.loginActivity_password);
        loginActivity_loginBtn = (Button) findViewById(R.id.loginActivity_loginBtn);
        loginActivity_newUser = (TextView) findViewById(R.id.loginActivity_registerUserText);
        loginActivity_firebaseAuth = FirebaseAuth.getInstance();

    }
}